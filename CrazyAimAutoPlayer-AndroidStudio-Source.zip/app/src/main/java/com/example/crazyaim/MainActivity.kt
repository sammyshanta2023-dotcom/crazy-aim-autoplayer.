package com.example.crazyaim

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "Crazy Aim Auto Player — prototype"
            textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "\nThis prototype contains the ricochet planner and an Android accessibility tap service.\n\nIt does not yet automatically recognize enemies or map every wall in a live game."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "Enable tap service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(this@MainActivity, "Enable Crazy Aim Auto Player in Accessibility settings.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Open test tap screen"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, TapTestActivity::class.java))
            }
        })
        setContentView(root)
    }
}
