package com.example.crazyaim

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Geometry-only ricochet planner for axis-aligned rectangular obstacles.
 * Coordinates are in the same pixel space as the captured game screen.
 *
 * This is a starter solver: callers must supply calibrated target coordinates,
 * shooter coordinates, and obstacle rectangles. It does not detect these from
 * the game screen yet.
 */
data class Point2(val x: Double, val y: Double)
data class Rect2(val left: Double, val top: Double, val right: Double, val bottom: Double)
data class ShotPlan(val wallPoint: Point2, val target: Point2, val length: Double)

object RicochetPlanner {
    /**
     * Computes a single-bounce path using the mirror method against a vertical
     * or horizontal wall segment. The reflected target is mirrored across the
     * wall; the line from shooter to mirrored target intersects the wall.
     * The caller must verify the intersection lies on the wall segment and that
     * both path segments are clear of obstacles.
     */
    fun planVerticalWall(shooter: Point2, target: Point2, wallX: Double, wallTop: Double, wallBottom: Double): ShotPlan? {
        val mirrored = Point2(2.0 * wallX - target.x, target.y)
        val dx = mirrored.x - shooter.x
        if (abs(dx) < 1e-9) return null
        val t = (wallX - shooter.x) / dx
        if (t <= 0.0 || t >= 1.0) return null
        val y = shooter.y + t * (mirrored.y - shooter.y)
        if (y < wallTop || y > wallBottom) return null
        val bounce = Point2(wallX, y)
        return ShotPlan(bounce, target, hypot(bounce.x - shooter.x, bounce.y - shooter.y) + hypot(target.x - bounce.x, target.y - bounce.y))
    }

    fun planHorizontalWall(shooter: Point2, target: Point2, wallY: Double, wallLeft: Double, wallRight: Double): ShotPlan? {
        val mirrored = Point2(target.x, 2.0 * wallY - target.y)
        val dy = mirrored.y - shooter.y
        if (abs(dy) < 1e-9) return null
        val t = (wallY - shooter.y) / dy
        if (t <= 0.0 || t >= 1.0) return null
        val x = shooter.x + t * (mirrored.x - shooter.x)
        if (x < wallLeft || x > wallRight) return null
        val bounce = Point2(x, wallY)
        return ShotPlan(bounce, target, hypot(bounce.x - shooter.x, bounce.y - shooter.y) + hypot(target.x - bounce.x, target.y - bounce.y))
    }
}
