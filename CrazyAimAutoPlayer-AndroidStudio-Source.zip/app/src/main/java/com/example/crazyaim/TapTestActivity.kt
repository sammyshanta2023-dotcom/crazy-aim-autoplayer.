package com.example.crazyaim

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class TapTestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Tap service test"
            textSize = 22f
        })
        layout.addView(TextView(this).apply {
            text = "Use only after enabling the accessibility service. This sends one test tap at the center of the current display."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Send one center tap"
            setOnClickListener {
                val dm = resources.displayMetrics
                val svc = GameTapService.instance
                if (svc == null) {
                    Toast.makeText(this@TapTestActivity, "Enable the accessibility service first.", Toast.LENGTH_LONG).show()
                } else {
                    svc.tap(dm.widthPixels / 2f, dm.heightPixels / 2f)
                    Toast.makeText(this@TapTestActivity, "One tap sent.", Toast.LENGTH_SHORT).show()
                }
            }
        })
        setContentView(layout)
    }
}
