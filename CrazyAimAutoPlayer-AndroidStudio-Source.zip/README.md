# Crazy Aim Auto Player — Android prototype

This is an Android Studio source project, not a prebuilt APK.

## Included
- Kotlin Android app shell.
- Accessibility service capable of sending a single tap gesture.
- A geometry-based single-wall ricochet planner (`RicochetPlanner.kt`).
- A basic tap-service test screen.

## Important status
This is a **prototype**, not a finished automatic player. It does not yet:
- capture the game screen continuously;
- automatically recognize human-shaped enemies or brick-wall boundaries;
- test candidate paths against all obstacles;
- verify hit/miss outcomes;
- automatically dismiss ads or resume play.

Those require implementation and on-device validation. The planner expects calibrated pixel coordinates and wall segments as inputs. It uses the mirror method for equal-angle reflection.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Build > Build APK(s).
4. Install the debug APK on your own device.

## Test tap service
1. Install and open the app.
2. Press **Enable tap service** and enable the service in Android Accessibility settings.
3. Return to the app and open **Open test tap screen**.
4. Press **Send one center tap**. This sends one tap at the display center.

Android may restrict interaction when Crazy Aim is backgrounded; this project does not bypass those restrictions.
